<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - VitaCare Clínica Médica</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../../css/geral.css">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="icon" href="../../img/favicon.ico" type="image/x-icon">
</head>
<body>
    <?php
    // Incluir configurações e verificar login
    require_once '../../../includes/config.php';
    verificar_login(); // Esta função já inicia a sessão e verifica o login
    ?>
    
    <!-- Header Área Restrita -->
    <header class="header">
        <div class="container">
            <a href="dashboard.php" class="logo">
                <i class="fas fa-heartbeat"></i> VitaCare - Área Restrita
            </a>
            <div class="header-info">
                <span id="user-info"><i class="fas fa-user"></i>  <?php echo htmlspecialchars($_SESSION['funcionario_nome']); ?></span>
                <button class="btn btn-outline-light btn-sm ml-3" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>
        </div>
    </header>

    <!-- Navegação Área Restrita -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Alternar navegação">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cadastrosDropdown" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                            <i class="fas fa-plus-circle"></i> Cadastros
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="cadastrosDropdown">
                            <li><a class="dropdown-item" href="cadastro_funcionario.php">
                                <i class="fas fa-user-tie"></i> Funcionários
                            </a></li>
                            <li><a class="dropdown-item" href="cadastro_medico.php">
                                <i class="fas fa-user-md"></i> Médicos
                            </a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="listagensDropdown" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                            <i class="fas fa-list"></i> Listagens
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="listagensDropdown">
                            <li><a class="dropdown-item" href="listar_funcionarios.php">
                                <i class="fas fa-users"></i> Funcionários
                            </a></li>
                            <li><a class="dropdown-item" href="listar_medicos.php">
                                <i class="fas fa-user-md"></i> Médicos
                            </a></li>
                            <li><a class="dropdown-item" href="listar_agendamentos.php">
                                <i class="fas fa-calendar-alt"></i> Agendamentos
                            </a></li>
                            <li><a class="dropdown-item" href="listar_contatos.php">
                                <i class="fas fa-envelope"></i> Contatos
                            </a></li>
                        </ul>
                    </li>
                </ul>
                <a href="../../../index.html" class="btn btn-outline-light ms-lg-3 mt-3 mt-lg-0">
                    <i class="fas fa-globe"></i> Site Público
                </a>
            </div>
        </div>
    </nav>

    <!-- Conteúdo Principal -->
    <main class="main-content">
        <div class="container">
            <!-- Boas-vindas -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="mb-0">
                                <i class="fas fa-tachometer-alt text-primary"></i> 
                                Dashboard - Painel de Controle
                            </h2>
                            <p class="text-muted mb-0">Bem-vindo ao sistema de gestão da VitaCare</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Estatísticas -->
            <div class="row mb-4" id="estatisticas-container">
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card funcionarios">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Funcionários</div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card medicos">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Médicos</div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card agendamentos">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Agendamentos</div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card contatos">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Contatos</div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card hoje">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Hoje</div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-3">
                    <div class="stat-card especialidades">
                        <div class="stat-number" data-bs-target="0">0</div>
                        <div class="stat-label">Especialidades</div>
                    </div>
                </div>
            </div>

            <!-- Ações Rápidas -->
            <div class="row mb-4 actions">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-bolt"></i> Ações Rápidas
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 col-md-6 mb-3">
                                    <a href="cadastro_funcionario.php" class="btn btn-primary w-100 text-center py-4">
                                        <i class="fas fa-user-plus fa-2x"></i><br>
                                        <small>Cadastrar Funcionário</small>
                                    </a>
                                </div>
                                <div class="col-lg-3 col-md-6 mb-3">
                                    <a href="cadastro_medico.php" class="btn btn-success w-100 text-center py-4">
                                        <i class="fas fa-user-md fa-2x"></i><br>
                                        <small>Cadastrar Médico</small>
                                    </a>
                                </div>
                                <div class="col-lg-3 col-md-6 mb-3">
                                    <a href="listar_agendamentos.php" class="btn btn-info w-100 text-center py-4">
                                        <i class="fas fa-calendar-alt fa-2x"></i><br>
                                        <small>Ver Agendamentos</small>
                                    </a>
                                </div>
                                <div class="col-lg-3 col-md-6 mb-3">
                                    <a href="listar_contatos.php" class="btn btn-warning w-100 text-center py-4">
                                        <i class="fas fa-envelope fa-2x"></i><br>
                                        <small>Ver Contatos</small>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Especialidades Mais Procuradas -->
            <div class="row mb-4">
                <div class="col-lg-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-chart-bar"></i> Especialidades Mais Procuradas
                            </h5>
                        </div>
                        <div class="card-body">
                            <div id="especialidades-populares">
                                <div class="text-center">
                                    <div class="spinner"></div>
                                    <p>Carregando dados...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Agendamentos Recentes -->
                <div class="col-lg-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-clock"></i> Agendamentos Recentes
                            </h5>
                        </div>
                        <div class="card-body">
                            <div id="agendamentos-recentes">
                                <div class="text-center">
                                    <div class="spinner"></div>
                                    <p>Carregando agendamentos...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Informações do Sistema -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-info-circle"></i> Informações do Sistema
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <h6><i class="fas fa-server text-primary"></i> Sistema</h6>
                                    <p class="small text-muted">VitaCare v1.0<br>Desenvolvido para UFU</p>
                                </div>
                                <div class="col-md-4">
                                    <h6><i class="fas fa-calendar text-success"></i> Último Acesso</h6>
                                    <p class="small text-muted" id="ultimo-acesso">Carregando...</p>
                                </div>
                                <div class="col-md-4">
                                    <h6><i class="fas fa-shield-alt text-warning"></i> Segurança</h6>
                                    <p class="small text-muted">Conexão segura<br>Dados protegidos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <p>&copy; 2024 VitaCare Clínica Médica - Sistema de Gestão Interno</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../js/geral.js"></script>
    <script src="../../js/dashboard.js"></script>
    <script src="../../js/script.js"></script>
</body>
</html>

