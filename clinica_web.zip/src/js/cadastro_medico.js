document.addEventListener("DOMContentLoaded", function() {

    const crmInput = document.getElementById('crm');
    if (crmInput) {
        aplicarMascaraCRM(crmInput);
    }
});
